const data = [
  {
      id: 1,
      name: "Chilman Mehrotra",
      email: "chilmanmehrotra@spottabl.com",
      designation: "Client Manager",
  },
  {
      id: 2,
      name: "Saboor Sirwal",
      email: "saboorsirwal@spottabl.com",
      designation: "Recruitment Success",
  },
  {
      id: 3,
      name: "Sajid Ali",
      email: "sajidali@spottabl.com",
      designation: "Software Engineer",
  },
  {
      id: 4,
      name: "Smriti Wadhwa",
      email: "smritiwadhwa@spotabbl.com",
      designation: "Software Engineer",
  },
  {
      id: 5,
      name: "Vanishri",
      email: "vani@spotabbl.com",
      designation: "Client Manager",
  },
  {
      id: 6,
      name: "Vishal N",
      email: "vishal@spotabbl.com",
      designation: "Senior Manager",
  },
];

export default data;
